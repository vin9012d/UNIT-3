function navbar(){
    return `<h3>
    <a href="index.html">Home Page</a>
</h3>
<h3>
    <a href="./electronics.html">Electronics</a>
</h3>
<h3>
    <a href="./jwelory.html">Jwelory</a>
</h3>
<h3>
    <a href="#">Login</a>
</h3>
<h3>
    <a href="#">SignUP</a>
</h3>`;
}

export default navbar;